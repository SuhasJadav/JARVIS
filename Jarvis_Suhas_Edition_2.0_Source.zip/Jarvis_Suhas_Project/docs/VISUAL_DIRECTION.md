# Visual direction

The supplied reference images were used only as design inspiration:
- dark black HUD
- cyan/amber reactor rings
- central persistent core
- thin technical grids and circular diagnostics
- large clear white response text near the bottom
- open/close/restart states should animate the reactor from dim -> spin-up -> stable -> dim.

Do not copy movie frames, logos, Iron Man suit artwork, or proprietary JARVIS voice recordings into the repository.
