# Setup guide

## A. Windows laptop — recommended

### 1. Install Python

Use Python 3.13 64-bit from the official Python site.

During installation:
- tick **Add python.exe to PATH**
- choose the normal 64-bit installer
- then open PowerShell and check:

```powershell
py -3.13 --version
```

### 2. Run Jarvis

Open PowerShell in the project folder:

```powershell
cd desktop
py -3.13 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

Or double-click `scripts\run_desktop.bat`.

### 3. Offline voice

The desktop version intentionally does not send microphone audio to a cloud speech service.

Install a Vosk model into:

```text
desktop/models/<model-folder>
```

and set:

```powershell
$env:VOSK_MODEL_PATH="$PWD\models\<model-folder>"
```

Then run Jarvis.

For English/Indian-English, use an appropriate Vosk model from the official Vosk model repository. Multilingual quality depends on the model. If you need high-quality Gujarati/Hindi/French, keep text input as a fallback or later integrate a local Whisper model.

### 4. Online features

By default, online mode is OFF.

Enable it for Google/YouTube/weather/local Ollama:

```powershell
$env:JARVIS_ONLINE="1"
python main.py
```

Google/YouTube are opened in your browser. Weather uses Open-Meteo. These are network actions, so they are not "offline/private".

### 5. Local AI chat (optional)

Install Ollama separately and download a small local model. Then set:

```powershell
$env:JARVIS_ONLINE="1"
$env:OLLAMA_MODEL="llama3.2:3b"
```

Jarvis calls `127.0.0.1` only. Do not change `OLLAMA_URL` to a public server if you want the strict privacy model.

## B. Android phone

### Important

You can install an already-built APK directly on Android without a laptop. **But this chat environment cannot honestly provide a compiled APK binary without an Android build toolchain.** The project supplied here contains the full Android source; build it once on a laptop, then copy the resulting APK to your phone. After that, future APKs can be built from the same project.

### Android Studio

Install the current stable Android Studio from the official Android Developers site.

Open the `android` folder as a project.

Android Studio will install the required SDK packages.

### Physical phone

1. On the phone open Settings > About phone.
2. Tap Build number seven times to enable Developer options.
3. Enable USB debugging.
4. Connect USB.
5. Accept the computer authorization dialog.
6. In Android Studio choose the phone.
7. Run the `app` configuration.

### Build APK

In Android Studio:
- Build > Generate App Bundles or APKs > Generate APKs.

Or terminal:

```powershell
cd android
.\gradlew.bat assembleDebug
```

APK output:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

Copy that APK to your phone and install it.

## C. Phone-only option

If you already have the APK:
1. Send/copy `app-debug.apk` to the phone.
2. Open it in Files.
3. Allow installation from that source if Android asks.
4. Install.

A completely laptop-free **source build** is possible only if an Android build environment is installed on the phone; that is much harder and not recommended for this project.

## D. GitHub

### GitHub Desktop

Install GitHub Desktop.

Then:
1. Create a GitHub repository named `jarvis-suhas-edition`.
2. In GitHub Desktop: File > Add local repository.
3. Select the project root.
4. Commit all files.
5. Push origin.

Never commit:
- `.env`
- API keys
- passwords
- Android keystore files
- Vosk/Whisper model files
- bridge tokens

### Command-line alternative

```powershell
cd Jarvis_Suhas_Project
git init
git add .
git commit -m "Initial Jarvis Suhas Edition 2.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/jarvis-suhas-edition.git
git push -u origin main
```

## E. Phone ↔ laptop architecture

```text
             ┌──────────────────────┐
             │ Android Jarvis       │
             │ mic + TTS + HUD      │
             └──────────┬───────────┘
                        │ LAN + token
                        ▼
             ┌──────────────────────┐
             │ Laptop Jarvis Bridge │
             │ 127.0.0.1 / LAN      │
             └──────────┬───────────┘
                        │
          ┌─────────────┼─────────────┐
          ▼             ▼             ▼
      allow-list     local AI      browser
      OS actions     (Ollama)      searches
```

Only commands supported by the allow-list should ever cross the bridge.

## F. What is deliberately not promised

No program can be "100% unhackable", "100% unable to leak data", or guarantee that a compromised operating system cannot interfere with it. The project therefore uses least privilege, no background service, no password storage, no arbitrary command execution and no telemetry.
