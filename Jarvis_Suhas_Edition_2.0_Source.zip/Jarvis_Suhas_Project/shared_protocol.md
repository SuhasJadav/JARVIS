# Local bridge protocol

Desktop listens on TCP port 8765.

POST:
`http://LAPTOP_IP:8765/command`

Headers:
`X-Jarvis-Token: <runtime token>`

JSON:
```json
{"command":"battery"}
```

Response:
```json
{"ok":true,"response":"Battery is at 84 percent."}
```

The desktop bridge only calls the same allow-listed command router used by the UI. It never evaluates arbitrary Python, PowerShell, CMD or shell text.
