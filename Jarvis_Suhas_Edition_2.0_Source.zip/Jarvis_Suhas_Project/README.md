# JARVIS — Suhas Edition 2.0

A privacy-first, original Iron-Man-inspired desktop + Android assistant prototype.

> **Important:** This project deliberately does **not** copy Marvel/Iron Man/JARVIS artwork, voices, logos, or movie assets. The HUD/reactor animation is drawn procedurally so the GitHub project can use original code/assets.

## Features in this version

### Desktop (Windows 10/11)
- "Hello sir" startup sequence with battery status.
- Animated reactor/HUD interface and response text.
- Voice input through an **offline Vosk model** (optional); text input always available.
- Offline Windows TTS through `pyttsx3`.
- English / Hindi / Gujarati / French command aliases.
- Wake phrase handling: say "Jarvis" during listening to activate.
- Google search / YouTube search in browser.
- Weather lookup through Open-Meteo when online mode is enabled.
- Battery and basic system status.
- Safe allow-listed typing and erase commands through PyAutoGUI.
- Shutdown/restart with a second confirmation phrase.
- Wi-Fi enable/disable through Windows `netsh` only after explicit confirmation and only for the configured interface.
- Local laptop HTTP bridge with a random token for the Android companion.
- Optional local Ollama chat endpoint. No cloud LLM is required.
- No password manager, payments, telemetry, analytics, cloud database, or persistent conversation history.

### Android
- Native Kotlin app.
- Same original reactor/HUD style.
- Android SpeechRecognizer + Android Text-to-Speech.
- Flashlight on/off.
- Battery status.
- Google / YouTube search.
- Weather via browser/Open-Meteo URL.
- Text commands and voice commands.
- Touch pinch/zoom on the central HUD.
- Optional LAN connection to the desktop bridge.
- Does not run a background service.

## Features intentionally not included
- Automatic call answering/rejecting: Android call-control permissions/roles vary by OS/device and can be invasive. The safe build opens the phone dialer instead.
- Direct Wi-Fi radio toggling on modern Android: Android restricts third-party apps from silently changing Wi-Fi state. The app can open the Internet panel.
- Game-playing/auto-clicking: omitted because it is risky, game-dependent and can violate game rules.
- "Impossible to hack" guarantee: no software can honestly make that guarantee. This project minimizes attack surface instead.

## Privacy model
Default design:
1. No password storage.
2. No payment capability.
3. No background service.
4. No analytics/ads.
5. No cloud account.
6. No conversation database.
7. Desktop AI is local-only when Ollama is used.
8. Web search/weather are opt-in network actions.
9. System actions are an explicit allow-list, never arbitrary shell commands.
10. Android-to-laptop commands require a local token.

## Quick start

See `docs/SETUP.md` for the complete Windows and Android setup instructions.

Desktop:
```text
cd desktop
py -3.13 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

If you want offline speech:
- install a Vosk speech model locally;
- set `VOSK_MODEL_PATH` in the environment or edit `desktop/config.py`.

Android:
- Open `android/` in Android Studio.
- Let Gradle sync.
- Connect an Android phone with USB debugging or use an emulator.
- Run the `app` configuration.
- Build > Build APK(s).

## Project layout

```text
Jarvis_Suhas_Project/
├── desktop/
│   ├── main.py
│   ├── config.py
│   └── requirements.txt
├── android/
│   ├── settings.gradle.kts
│   ├── build.gradle.kts
│   ├── gradle.properties
│   └── app/
├── docs/
│   └── SETUP.md
├── scripts/
│   ├── run_desktop.bat
│   └── build_android.bat
├── SECURITY.md
├── LICENSE
└── .gitignore
```
