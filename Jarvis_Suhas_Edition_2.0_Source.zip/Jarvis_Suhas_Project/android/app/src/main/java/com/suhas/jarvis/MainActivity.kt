package com.suhas.jarvis

import android.Manifest
import android.app.Activity
import android.content.*
import android.net.Uri
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var hud: HudView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var flashOn = false
    private val owner = "Suhas Jadav"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3,6,11)
        window.navigationBarColor = Color.rgb(3,6,11)

        val root = FrameLayout(this)
        hud = HudView(this)
        root.addView(hud, FrameLayout.LayoutParams(-1, -1))

        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        controls.setPadding(12, 8, 12, 8)
        controls.setBackgroundColor(Color.argb(230, 5, 10, 18))

        fun button(label: String, action: () -> Unit): Button {
            val b = Button(this)
            b.text = label
            b.setTextColor(Color.WHITE)
            b.setOnClickListener { action() }
            return b
        }

        controls.addView(button("MIC") { toggleListening() })
        controls.addView(button("FLASH") { toggleFlash() })
        controls.addView(button("SEARCH") { searchDialog(false) })
        controls.addView(button("YT") { searchDialog(true) })

        val lp = FrameLayout.LayoutParams(-1, 64)
        lp.gravity = Gravity.BOTTOM
        root.addView(controls, lp)
        setContentView(root)

        tts = TextToSpeech(this, this)
        requestPermissionsIfNeeded()
        speak("Systems online. Good to have you back, sir. Aapka personal system active hai. Version 2.0. Awaiting your command, sir.")
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            tts.setSpeechRate(0.92f)
        }
    }

    private fun speak(text: String) {
        hud.setResponse(text)
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun toggleListening() {
        if (listening) {
            recognizer?.stopListening()
            listening = false
            speak("Voice input paused, sir.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this device, sir.")
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { speak("Yes sir. I am listening.") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(error: Int) { listening = false; speak("I could not hear that clearly, sir.") }
            override fun onResults(results: Bundle?) {
                listening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                handleCommand(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        listening = true
        recognizer!!.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val text = raw.trim()
        val low = text.lowercase(Locale.getDefault())

        if (low.contains("jarvis")) {
            speak("Welcome back, sir.")
        }

        when {
            low.contains("flashlight on") || low.contains("flash on") || low.contains("torch on") ||
                    low.contains("ફ્લેશલાઇટ ચાલુ") || low.contains("टॉर्च चालू") -> {
                setFlash(true)
            }
            low.contains("flashlight off") || low.contains("flash off") || low.contains("torch off") ||
                    low.contains("ફ્લેશલાઇટ બંધ") || low.contains("टॉर्च बंद") -> {
                setFlash(false)
            }
            low.contains("battery") || low.contains("બેટરી") || low.contains("बैटरी") -> {
                val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
                val pct = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                speak("Battery is at $pct percent, sir.")
            }
            low.startsWith("google ") || low.startsWith("search ") -> {
                val q = text.replaceFirst(Regex("(?i)^(google|search)\\s*"), "")
                openSearch(q, false)
            }
            low.startsWith("youtube ") -> {
                val q = text.replaceFirst(Regex("(?i)^youtube\\s*"), "")
                openSearch(q, true)
            }
            low.contains("weather") || low.contains("હવામાન") || low.contains("मौसम") -> {
                openSearch("weather today", false)
            }
            low.contains("intro") || low.contains("who are you") -> {
                speak("Hello, I am Jarvis. I am a computer assistant program. I was built for Engineer $owner. I understand English, Hindi, Gujarati and French.")
            }
            low.contains("open google") -> {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
                speak("Google is open, sir.")
            }
            else -> {
                speak("I heard: $text. I can search, report battery, control the flashlight and connect to the laptop bridge.")
            }
        }
    }

    private fun openSearch(q: String, youtube: Boolean) {
        val base = if (youtube) "https://www.youtube.com/results?search_query=" else "https://www.google.com/search?q="
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(base + URLEncoder.encode(q, "UTF-8"))))
        speak("Searching for $q, sir.")
    }

    private fun searchDialog(youtube: Boolean) {
        val input = EditText(this)
        input.hint = if (youtube) "YouTube search" else "Google search"
        AlertDialog.Builder(this)
            .setTitle(if (youtube) "YouTube" else "Google")
            .setView(input)
            .setPositiveButton("SEARCH") { _, _ -> openSearch(input.text.toString(), youtube) }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun toggleFlash() {
        setFlash(!flashOn)
    }

    private fun setFlash(on: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) {
                speak("This phone does not expose a camera flashlight, sir.")
                return
            }
            cm.setTorchMode(cameraId, on)
            flashOn = on
            speak(if (on) "Flashlight on, sir." else "Flashlight off, sir.")
        } catch (e: Exception) {
            speak("I could not control the flashlight on this device, sir.")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
