package com.suhas.jarvis

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.min

class HudView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var zoom = 1f
    private var response = "Awaiting your command, sir."
    private val scaleDetector = ScaleGestureDetector(context, object: ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoom = (zoom * detector.scaleFactor).coerceIn(0.65f, 1.45f)
            invalidate()
            return true
        }
    })

    fun setResponse(text: String) {
        response = text
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Color.rgb(3, 6, 11))
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f

        for (x in 0..width step 48) {
            p.color = Color.rgb(7, 18, 27)
            c.drawLine(x.toFloat(), 0f, x.toFloat(), h, p)
        }
        for (y in 0..height step 48) {
            p.color = Color.rgb(7, 18, 27)
            c.drawLine(0f, y.toFloat(), w, y.toFloat(), p)
        }

        val cx = w / 2f
        val cy = h * .42f
        val maxR = min(w, h) * .34f * zoom

        for (i in 0..8) {
            val r = maxR * (.23f + i * .085f)
            p.color = if (i % 2 == 0) Color.rgb(18, 170, 210) else Color.rgb(240, 160, 35)
            p.strokeWidth = if (i == 4) 4f else 2f
            c.drawCircle(cx, cy, r, p)
            val start = (phase * (20 + i * 7)) % 360f
            c.drawArc(cx-r, cy-r, cx+r, cy+r, start, 52f, false, p)
        }

        p.color = Color.WHITE
        p.strokeWidth = 2f
        c.drawCircle(cx, cy, 36f * zoom, p)
        p.color = Color.rgb(20, 215, 255)
        p.strokeWidth = 6f
        c.drawCircle(cx, cy, 68f * zoom, p)
        p.color = Color.rgb(240, 166, 43)
        p.strokeWidth = 3f
        c.drawCircle(cx, cy, 94f * zoom, p)

        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.textSize = 22f
        c.drawText("J A R V I S", cx, cy + 7f, p)

        p.textAlign = Paint.Align.LEFT
        p.textSize = 18f
        c.drawText("JARVIS / SUHAS EDITION 2.0", 24f, 34f, p)
        p.textSize = 11f
        p.color = Color.rgb(120, 220, 255)
        c.drawText("OWNER: SUHAS JADAV", 24f, 55f, p)

        p.textAlign = Paint.Align.RIGHT
        c.drawText("ORIGINAL HUD • NO MOVIE ASSETS", w - 24f, 34f, p)

        // response panel
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = Color.rgb(10, 110, 145)
        val top = h - 170f
        c.drawRoundRect(24f, top, w-24f, h-48f, 12f, 12f, p)

        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.textSize = 14f
        val maxChars = 68
        val chunks = response.chunked(maxChars).take(3)
        chunks.forEachIndexed { i, line ->
            c.drawText(line, cx, top + 38f + i*24f, p)
        }

        phase += .7f
        postInvalidateDelayed(33)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        return true
    }
}
