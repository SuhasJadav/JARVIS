@echo off
cd /d "%~dp0..\desktop"
if not exist ".venv\Scripts\python.exe" (
  py -3.13 -m venv .venv
  call .venv\Scripts\activate
  python -m pip install --upgrade pip
  pip install -r requirements.txt
) else (
  call .venv\Scripts\activate
)
python main.py
pause
