@echo off
cd /d "%~dp0..\android"
gradlew.bat assembleDebug
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
