# Security design

This is a defensive, privacy-first architecture, not a promise of perfect security.

## Threat-reduction choices

- No arbitrary shell execution from voice/text.
- Only predefined commands are mapped to OS actions.
- Shutdown/restart/Wi-Fi actions require confirmation.
- Laptop bridge uses a random token and binds to the local network interface.
- No credentials are accepted or stored.
- No payment APIs.
- No browser cookies or saved passwords are read.
- No startup/background service is installed.
- No telemetry.
- Conversation text is kept in RAM only for the current session.
- Online features are explicit and can be disabled.
- Local Ollama is used instead of a cloud LLM when available.

## Before publishing

For a public GitHub release:
1. Do not commit `.env`, tokens, model files or API keys.
2. Add automated tests.
3. Sign the Android release APK with your own keystore.
4. Review third-party licenses.
5. Run dependency vulnerability scanning.
6. Do a manual permission review.
7. Keep the default network mode off if privacy is more important than online search.

## Important limitation

If a device is already compromised, no application can guarantee that malware cannot read the device, screen, microphone, clipboard, or network traffic. The correct goal is to minimize privileges and isolate risky operations.
