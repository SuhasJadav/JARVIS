from pathlib import Path
import os

OWNER_NAME = "Suhas Jadav"
WAKE_WORDS = {"jarvis", "जार्विस", "જાર્વિસ"}

# No data is persisted by the application. These are runtime-only settings.
ONLINE_MODE = os.getenv("JARVIS_ONLINE", "0") == "1"
VOSK_MODEL_PATH = Path(os.getenv("VOSK_MODEL_PATH", "./models/vosk-model-small-en-in-0.4"))
BRIDGE_HOST = os.getenv("JARVIS_BRIDGE_HOST", "0.0.0.0")
BRIDGE_PORT = int(os.getenv("JARVIS_BRIDGE_PORT", "8765"))
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434/api/generate")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:3b")

# Change this only if Windows uses a different adapter name.
WIFI_INTERFACE_NAME = os.getenv("JARVIS_WIFI_INTERFACE", "Wi-Fi")
