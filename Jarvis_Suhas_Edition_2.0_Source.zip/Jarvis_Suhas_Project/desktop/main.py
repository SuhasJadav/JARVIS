import json
import os
import queue
import random
import re
import secrets
import subprocess
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote_plus

import tkinter as tk
from tkinter import messagebox

import psutil
import pyttsx3
import requests

from config import (
    OWNER_NAME, ONLINE_MODE, VOSK_MODEL_PATH, BRIDGE_HOST, BRIDGE_PORT,
    OLLAMA_URL, OLLAMA_MODEL, WIFI_INTERFACE_NAME
)

try:
    import pyautogui
except Exception:
    pyautogui = None

try:
    import sounddevice as sd
    from vosk import Model, KaldiRecognizer
except Exception:
    sd = None
    Model = None
    KaldiRecognizer = None


RESPONSES = [
    "Yes sir.",
    "At your service, sir.",
    "Welcome back, sir.",
    "Certainly, sir.",
    "Right away, sir.",
    "Systems ready, sir.",
]

STARTUP = (
    "Systems online. Good to have you back, sir. "
    "Aapka personal system active hai. Everything is running at peak performance. "
    "Speed 1 terahertz. Memory 1 zigabyte. All cores locked at peak performance. "
    "Processor running at peak performance. Version 2.0. Awaiting your command, sir."
)

INTRO = (
    f"Hello, I am Jarvis. I am a computer assistant program. "
    f"I was built for Engineer {OWNER_NAME}. "
    "I can understand English, Hindi, Gujarati and French. "
    "I can control approved computer functions, search the web and report system status."
)

JOKES = [
    "Why did the computer get cold? It left its Windows open, sir.",
    "I would tell you a UDP joke, sir, but you might not get it.",
    "My favorite exercise is a screen refresh, sir.",
]

TRANSLATIONS = {
    "hello": "Hello, sir.",
    "namaste": "Namaste, sir.",
    "kem cho": "Majama, sir. Systems are stable.",
    "bonjour": "Bonjour, monsieur.",
    "salut": "Salut, sir.",
    "હેલો": "હેલો સર.",
    "નમસ્તે": "નમસ્તે સર.",
}


def battery_text():
    try:
        b = psutil.sensors_battery()
        if b is None:
            return "Battery status unavailable."
        return f"Battery is at {b.percent:.0f} percent."
    except Exception:
        return "Battery status unavailable."


def safe_url_search(query, youtube=False):
    base = "https://www.youtube.com/results?search_query=" if youtube else "https://www.google.com/search?q="
    webbrowser.open(base + quote_plus(query))
    return f"Searching {'YouTube' if youtube else 'Google'} for {query}, sir."


def weather(query):
    if not ONLINE_MODE:
        return "Online mode is disabled. Set JARVIS_ONLINE=1 to enable weather."
    city = query.strip() or "Vadodara"
    try:
        geo = requests.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": city, "count": 1, "language": "en", "format": "json"},
            timeout=6,
        ).json()
        results = geo.get("results", [])
        if not results:
            return f"I could not find {city}, sir."
        place = results[0]
        lat, lon = place["latitude"], place["longitude"]
        data = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat, "longitude": lon,
                "current": "temperature_2m,relative_humidity_2m,wind_speed_10m",
                "timezone": "auto",
            },
            timeout=6,
        ).json()["current"]
        return (
            f"{place.get('name', city)} weather: {data['temperature_2m']} degrees Celsius, "
            f"humidity {data['relative_humidity_2m']} percent, "
            f"wind {data['wind_speed_10m']} kilometres per hour."
        )
    except Exception as e:
        return f"Weather service is unavailable right now, sir."


def ollama_chat(text):
    if not ONLINE_MODE:
        return None
    # Local-only endpoint. It never leaves this PC unless Ollama itself is configured remotely.
    try:
        r = requests.post(
            OLLAMA_URL,
            json={
                "model": OLLAMA_MODEL,
                "prompt": (
                    "You are a concise personal assistant named Jarvis. "
                    f"Address the owner as sir. Owner: {OWNER_NAME}. "
                    "Never claim to control functions you cannot actually control. "
                    "Never ask for or store passwords. Answer briefly.\nUser: " + text
                ),
                "stream": False,
            },
            timeout=25,
        )
        if r.ok:
            return r.json().get("response", "").strip() or None
    except Exception:
        return None
    return None


def allowlisted_action(text, app):
    t = text.strip()
    low = t.lower()

    if not t:
        return "I am listening, sir."

    if "intro" in low or "who are you" in low or "introduce yourself" in low:
        return INTRO

    if any(k in low for k in ("joke", "funny", "comedy")):
        return random.choice(JOKES)

    if "battery" in low or "बैटरी" in low or "બેટરી" in low:
        return battery_text()

    if low in TRANSLATIONS:
        return TRANSLATIONS[low]

    if low.startswith(("google ", "search google ", "search for ")):
        q = re.sub(r"^(google|search google|search for)\s+", "", t, flags=re.I)
        return safe_url_search(q)

    if low.startswith(("youtube ", "search youtube ", "youtube search ")):
        q = re.sub(r"^(youtube|search youtube|youtube search)\s+", "", t, flags=re.I)
        return safe_url_search(q, youtube=True)

    if low.startswith(("weather", "temperature", "મોસમ", "હવામાન", "मौसम")):
        q = re.sub(r"^(weather|temperature|મોસમ|હવામાન|मौसम)\s*", "", t, flags=re.I)
        return weather(q)

    if "type " in low or low.startswith(("type ", "लिखो ", "ટાઈપ ")):
        if pyautogui is None:
            return "Typing support is not installed, sir."
        payload = re.sub(r"^(type|लिखो|ટાઈપ)\s+", "", t, flags=re.I)
        if len(payload) > 1000:
            return "For safety, I only type up to 1000 characters at a time."
        pyautogui.write(payload, interval=0.01)
        return "Text entered, sir."

    if low in {"erase", "erase last", "delete", "मिटाओ", "ડિલીટ"}:
        if pyautogui is None:
            return "Typing support is not installed, sir."
        pyautogui.press("backspace", presses=20, interval=0.01)
        return "Erased the last text block, sir."

    if "shutdown" in low or "shut down" in low or "બંધ" in low:
        app.pending = "shutdown"
        return "Shutdown is armed. Say or type 'confirm shutdown' to proceed."

    if low == "confirm shutdown":
        subprocess.Popen(["shutdown", "/s", "/t", "10"])
        app.pending = None
        return "Shutdown confirmed. The computer will power off in ten seconds."

    if "restart" in low or "reboot" in low:
        app.pending = "restart"
        return "Restart is armed. Say or type 'confirm restart' to proceed."

    if low == "confirm restart":
        subprocess.Popen(["shutdown", "/r", "/t", "10"])
        app.pending = None
        return "Restart confirmed. The computer will restart in ten seconds."

    if "cancel shutdown" in low or "cancel restart" in low or low == "cancel":
        subprocess.Popen(["shutdown", "/a"])
        app.pending = None
        return "Pending power action cancelled, sir."

    if "wifi off" in low or "wi-fi off" in low or "internet off" in low:
        app.pending = "wifi_off"
        return f"Wi-Fi disable is armed for interface '{WIFI_INTERFACE_NAME}'. Say 'confirm wifi off'."

    if low == "confirm wifi off":
        subprocess.run(
            ["netsh", "interface", "set", "interface", f"name={WIFI_INTERFACE_NAME}", "admin=disabled"],
            capture_output=True, text=True, timeout=5
        )
        app.pending = None
        return "Wi-Fi disable command sent, sir."

    if "wifi on" in low or "wi-fi on" in low or "internet on" in low:
        app.pending = "wifi_on"
        return f"Wi-Fi enable is armed for interface '{WIFI_INTERFACE_NAME}'. Say 'confirm wifi on'."

    if low == "confirm wifi on":
        subprocess.run(
            ["netsh", "interface", "set", "interface", f"name={WIFI_INTERFACE_NAME}", "admin=enabled"],
            capture_output=True, text=True, timeout=5
        )
        app.pending = None
        return "Wi-Fi enable command sent, sir."

    if "open google" in low:
        webbrowser.open("https://www.google.com")
        return "Google is open, sir."

    if "open youtube" in low:
        webbrowser.open("https://www.youtube.com")
        return "YouTube is open, sir."

    if "stop listening" in low or "go to sleep" in low:
        app.listening = False
        return "Voice input paused. The application remains open, sir."

    # Local LLM is optional and disabled unless online mode is explicitly enabled.
    llm = ollama_chat(t)
    if llm:
        return llm

    return "I understood the request, sir. I can help with search, weather, battery, typing, power controls and approved system actions."


class BridgeHandler(BaseHTTPRequestHandler):
    server_version = "JarvisBridge/2.0"

    def do_POST(self):
        if self.path != "/command":
            self.send_response(404)
            self.end_headers()
            return
        token = self.headers.get("X-Jarvis-Token", "")
        if token != self.server.app.bridge_token:
            self.send_response(401)
            self.end_headers()
            return
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(min(length, 8192))
        try:
            payload = json.loads(body.decode("utf-8"))
            text = str(payload.get("command", ""))[:1000]
            result = allowlisted_action(text, self.server.app)
            data = json.dumps({"ok": True, "response": result}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception:
            self.send_response(400)
            self.end_headers()

    def log_message(self, fmt, *args):
        return


class JarvisApp:
    def __init__(self, root):
        self.root = root
        self.root.title("JARVIS — Suhas Edition 2.0")
        self.root.geometry("1200x760")
        self.root.minsize(900, 600)
        self.root.configure(bg="#03060b")
        self.pending = None
        self.listening = False
        self.active = False
        self.last_response = ""
        self.bridge_token = secrets.token_urlsafe(24)

        self.tts = pyttsx3.init()
        self.tts.setProperty("rate", 175)
        self.tts_lock = threading.Lock()

        self.canvas = tk.Canvas(root, bg="#03060b", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        bottom = tk.Frame(root, bg="#050a12")
        bottom.place(relx=0.5, rely=0.96, anchor="s", relwidth=0.92, height=52)
        self.entry = tk.Entry(bottom, bg="#0a1420", fg="white", insertbackground="white",
                              relief="flat", font=("Segoe UI", 13))
        self.entry.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        self.entry.bind("<Return>", lambda e: self.submit())
        tk.Button(bottom, text="SEND", command=self.submit, bg="#0b5b78", fg="white",
                  relief="flat", font=("Segoe UI", 10, "bold")).pack(side="right", padx=8, pady=8)

        self.canvas.bind("<Button-1>", lambda e: self.toggle_listening())
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.phase = 0.0
        self.draw_loop()
        self.startup()

        self.bridge = ThreadingHTTPServer((BRIDGE_HOST, BRIDGE_PORT), BridgeHandler)
        self.bridge.app = self
        threading.Thread(target=self.bridge.serve_forever, daemon=True).start()

    def speak(self, text):
        self.last_response = text
        self.root.after(0, self.refresh_text)
        def worker():
            with self.tts_lock:
                try:
                    self.tts.say(text)
                    self.tts.runAndWait()
                except Exception:
                    pass
        threading.Thread(target=worker, daemon=True).start()

    def startup(self):
        msg = STARTUP + " " + battery_text()
        self.active = True
        self.speak(msg)

    def refresh_text(self):
        pass

    def submit(self):
        text = self.entry.get().strip()
        self.entry.delete(0, "end")
        if text:
            if re.search(r"\bjarvis\b", text, re.I):
                self.active = True
            response = allowlisted_action(text, self)
            self.speak(response)

    def toggle_listening(self):
        if self.listening:
            self.listening = False
            self.speak("Voice input paused, sir.")
        else:
            self.listening = True
            self.active = True
            self.speak(random.choice(RESPONSES))
            threading.Thread(target=self.voice_loop, daemon=True).start()

    def voice_loop(self):
        if sd is None or Model is None or not VOSK_MODEL_PATH.exists():
            self.root.after(0, lambda: self.speak(
                "Offline voice model is not installed. Use the text box, or install a Vosk model locally."
            ))
            self.listening = False
            return

        try:
            model = Model(str(VOSK_MODEL_PATH))
            rec = KaldiRecognizer(model, 16000)
            audio_q = queue.Queue()

            def callback(indata, frames, time_info, status):
                audio_q.put(bytes(indata))

            with sd.RawInputStream(samplerate=16000, blocksize=8000, dtype="int16",
                                   channels=1, callback=callback):
                while self.listening:
                    data = audio_q.get()
                    if rec.AcceptWaveform(data):
                        result = json.loads(rec.Result()).get("text", "").strip()
                        if result:
                            self.root.after(0, lambda r=result: self.handle_voice(r))
        except Exception:
            self.root.after(0, lambda: self.speak("Microphone input failed, sir."))
            self.listening = False

    def handle_voice(self, text):
        if re.search(r"\bjarvis\b", text, re.I) or self.active:
            self.active = True
            response = allowlisted_action(text, self)
            self.speak(response)

    def draw_loop(self):
        self.phase += 0.035
        w, h = max(self.canvas.winfo_width(), 900), max(self.canvas.winfo_height(), 600)
        self.canvas.delete("all")
        cx, cy = w * 0.5, h * 0.46
        maxr = min(w, h) * 0.28

        # Background grid
        for x in range(0, w, 60):
            self.canvas.create_line(x, 0, x, h, fill="#07111a")
        for y in range(0, h, 60):
            self.canvas.create_line(0, y, w, y, fill="#07111a")

        # Decorative HUD rings
        for i in range(9):
            r = maxr * (0.25 + i * 0.09)
            start = (self.phase * (25 + i * 7)) % 360
            self.canvas.create_oval(cx-r, cy-r, cx+r, cy+r, outline="#0b9cc4", width=2)
            self.canvas.create_arc(cx-r, cy-r, cx+r, cy+r, start=start, extent=55,
                                   outline="#f0a020", width=3)
            self.canvas.create_arc(cx-r, cy-r, cx+r, cy+r, start=start+180, extent=30,
                                   outline="#1bd4ff", width=2)

        # Central original "reactor"
        self.canvas.create_oval(cx-95, cy-95, cx+95, cy+95, outline="#23d9ff", width=5)
        self.canvas.create_oval(cx-68, cy-68, cx+68, cy+68, outline="#f2a62b", width=3)
        self.canvas.create_oval(cx-35, cy-35, cx+35, cy+35, outline="#ffffff", width=2)
        self.canvas.create_text(cx, cy, text="J A R V I S", fill="white",
                                font=("Segoe UI", 20, "bold"))

        # Side status
        self.canvas.create_text(28, 28, anchor="nw", text="JARVIS / SUHAS EDITION 2.0",
                                fill="white", font=("Segoe UI", 16, "bold"))
        self.canvas.create_text(30, 58, anchor="nw", text=f"OWNER: {OWNER_NAME.upper()}",
                                fill="#8adfff", font=("Consolas", 10))
        self.canvas.create_text(w-30, 30, anchor="ne", text=battery_text(),
                                fill="#8adfff", font=("Consolas", 11))
        self.canvas.create_text(w-30, 55, anchor="ne",
                                text=f"BRIDGE : {BRIDGE_PORT} / TOKEN PROTECTED",
                                fill="#6a8290", font=("Consolas", 9))

        # Response panel with clean blank space
        panel_h = 100
        self.canvas.create_rectangle(40, h-panel_h-80, w-40, h-80,
                                     outline="#0c6f91", width=2, fill="#050b12")
        text = self.last_response or "Awaiting your command, sir."
        # wrap
        words = text.split()
        lines, cur = [], ""
        for word in words:
            if len(cur) + len(word) + 1 > 100:
                lines.append(cur)
                cur = word
            else:
                cur = (cur + " " + word).strip()
        if cur: lines.append(cur)
        lines = lines[:3]
        self.canvas.create_text(w/2, h-panel_h/2-80, text="\n".join(lines),
                                fill="white", width=w-120, justify="center",
                                font=("Segoe UI", 13))
        self.canvas.create_text(w/2, h-50, text="CLICK REACTOR = VOICE • TEXT BOX = COMMAND",
                                fill="#53707d", font=("Consolas", 9))
        self.root.after(33, self.draw_loop)

    def close(self):
        self.listening = False
        try:
            self.bridge.shutdown()
            self.bridge.server_close()
        except Exception:
            pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = JarvisApp(root)
    root.mainloop()
